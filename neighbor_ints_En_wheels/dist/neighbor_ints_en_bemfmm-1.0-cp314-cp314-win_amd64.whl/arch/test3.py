import numpy as np
from neighbor_ints_en_fmm import neighbor_ints_En

import os
os.environ["OMP_NUM_THREADS"] = "8"


P = np.array([
    [0.0, 0.0, 0.0],
    [1.2, 0.1, 0.0],
    [0.1, 1.1, 0.2],
    [0.0, 0.2, 1.3],
    [1.1, 0.9, 0.1],
    [0.2, 1.3, 1.1],
    [1.3, 0.2, 1.0],
    [0.9, 1.1, 1.4]
], dtype=np.float64)


t = np.array([
    [0,1,2],
    [0,3,1],
    [0,2,3],

    [1,4,2],
    [2,4,5],
    [2,5,3],

    [1,6,4],
    [3,5,7],
    [4,6,7],
    [5,7,6]
], dtype=np.uintp)


# geometry
a = P[t[:,1]] - P[t[:,0]]
b = P[t[:,2]] - P[t[:,0]]

cross = np.cross(a,b)

area = 0.5*np.linalg.norm(cross, axis=1)

normal = cross / np.linalg.norm(cross, axis=1)[:,None]

center = (
    P[t[:,0]] +
    P[t[:,1]] +
    P[t[:,2]]
) / 3.0


T = t.shape[0]

# intentionally non-patterned neighbors
neighbor = np.array([
    [0,4,2,7],
    [1,6,3,8],
    [2,9,0,5],
    [3,7,4,1],
    [4,2,8,6],
    [5,0,9,3],
    [6,8,1,7],
    [7,5,4,9],
    [8,6,2,0],
    [9,3,7,5]
], dtype=np.uintp)


IE, IC = neighbor_ints_En(
    P,
    t,
    normal,
    center,
    neighbor,
    area,
    1
)


print("IE")
print(IE)

print("\nIC")
print(IC)

print("\nchecks")
print("IE norm:", np.linalg.norm(IE))
print("IC norm:", np.linalg.norm(IC))