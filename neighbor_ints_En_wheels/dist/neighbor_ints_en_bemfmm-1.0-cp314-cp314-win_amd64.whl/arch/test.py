import numpy as np
from neighbor_ints_en_fmm import neighbor_ints_En
import os
os.environ["OMP_NUM_THREADS"] = "8"

P = np.array([
    [0.0, 0.0, 0.0],
    [1.0, 0.0, 0.0],
    [0.0, 1.0, 0.0],
    [0.0, 0.0, 1.0]
], dtype=np.float64)

t = np.array([
    [0, 1, 2],
    [0, 1, 3]
], dtype=np.uintp)

normal = np.array([
    [0.0,  0.0, 1.0],
    [0.0, -1.0, 0.0]
], dtype=np.float64)

center = np.array([
    [1.0/3.0, 1.0/3.0, 0.0],
    [1.0/3.0, 0.0, 1.0/3.0]
], dtype=np.float64)

area = np.array([
    0.5,
    0.5
], dtype=np.float64)

neighbor = np.array([
    [0, 1],
    [0, 1]
], dtype=np.uintp)

IE, IC = neighbor_ints_En(
    P,
    t,
    normal,
    center,
    neighbor,
    area,
    1
)

print("IE")
print(IE)

print("IC")
print(IC)
