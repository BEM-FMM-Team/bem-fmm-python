import numpy as np
from neighbor_ints_en_fmm import neighbor_ints_En
from scipy.io import savemat
import os
os.environ["OMP_NUM_THREADS"] = "8"
rng = np.random.default_rng(12345)

N = 5000
T = 20000
M = 100

P = rng.standard_normal((N,3))

t = np.empty((T,3), dtype=np.uintp)

for i in range(T):
    t[i] = rng.choice(N, size=3, replace=False)

a = P[t[:,1]] - P[t[:,0]]
b = P[t[:,2]] - P[t[:,0]]

cross = np.cross(a,b)

norms = np.linalg.norm(cross, axis=1)

good = norms > 1e-10

t = t[good]

cross = cross[good]

T = t.shape[0]

normal = cross / np.linalg.norm(cross, axis=1)[:,None]

area = 0.5*np.linalg.norm(cross, axis=1)

center = (
    P[t[:,0]] +
    P[t[:,1]] +
    P[t[:,2]]
)/3.0

neighbor = np.empty((T,M), dtype=np.uintp)

for i in range(T):
    neighbor[i] = rng.choice(T, size=M, replace=False)

# savemat("test_inputs.mat", {
#     "P": P,
#     "t": t,
#     "normal": normal,
#     "center": center,
#     "area": area,
#     "neighbor": neighbor
# })

IE, IC = neighbor_ints_En(
    P,
    t,
    normal,
    center,
    neighbor,
    area,
    1
)

np.save("IE_py.npy", IE)
np.save("IC_py.npy", IC)