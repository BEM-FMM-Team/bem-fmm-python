from scipy.io import loadmat
import numpy as np

IC = np.load("IC_py.npy")
IE = np.load("IE_py.npy")
mat = loadmat("matlab_output.mat")
IC_mat = mat["IC"]
IE_mat = mat["IE"]

print(np.linalg.norm(IE))
print(np.linalg.norm(IC))

print("IE max error:", np.max(np.abs(IE - IE_mat)))
print("IC max error:", np.max(np.abs(IC - IC_mat)))

print("IE rel error:",
      np.linalg.norm(IE - IE_mat) /
      np.linalg.norm(IE_mat))

print("IC rel error:",
      np.linalg.norm(IC - IC_mat) /
      np.linalg.norm(IC_mat))