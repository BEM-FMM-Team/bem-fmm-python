import numpy as np
from neighbor_ints_en_fmm import neighbor_ints_En

import os
os.environ["OMP_NUM_THREADS"] = "8"

import time

nx = 150
ny = 150

x = np.linspace(0, 1, nx)
y = np.linspace(0, 1, ny)

X, Y = np.meshgrid(x, y)

P = np.column_stack([
    X.ravel(),
    Y.ravel(),
    0.1*np.sin(3*X.ravel())*np.cos(2*Y.ravel())
])

t = []

for j in range(ny-1):
    for i in range(nx-1):
        v0 = j*nx + i
        v1 = v0 + 1
        v2 = v0 + nx
        v3 = v2 + 1

        t.append([v0, v1, v2])
        t.append([v1, v3, v2])

t = np.array(t, dtype=np.uintp)

N = P.shape[0]
T = t.shape[0]

normal = np.zeros((t.shape[0],3), dtype=np.float64)
normal[:,2] = 1.0

center = (
    P[t[:,0]] +
    P[t[:,1]] +
    P[t[:,2]]
) / 3.0

a = P[t[:,1]] - P[t[:,0]]
b = P[t[:,2]] - P[t[:,0]]

cross = np.cross(a,b)

area = 0.5*np.linalg.norm(cross,axis=1)

M = 10

neighbor = np.empty((T,M), dtype=np.uintp)

for i in range(T):
    for j in range(M):
        neighbor[i,j] = (i+j)%T

start = time.perf_counter()

IE, IC = neighbor_ints_En(
    P,
    t,
    normal,
    center,
    neighbor,
    area,
    1
)
end = time.perf_counter()

print("IE")
print(IE)

print("IC")
print(IC)

print(np.min(IE))
print(np.max(IE))
print(np.linalg.norm(IE))

print(np.min(IC))
print(np.max(IC))
print(np.linalg.norm(IC))

print(f"neighbor_ints_En runtime: {end-start:.6f} seconds")

print("IE shape:", IE.shape)
print("IC shape:", IC.shape)

print("IE sample:")
print(IE[:5,:5])

print("IC sample:")
print(IC[:5,:5])

from scipy.io import loadmat

matlab = loadmat("matlab_output.mat")

IE_matlab = matlab["IE"]
IC_matlab = matlab["IC"]
# t_matlab = matlab["t"] - 1
# P_matlab = matlab["P"] 

# t_diff = t - t_matlab
# P_diff = P - P_matlab

neighbor_matlab = matlab["neighbor"] - 1

IE_diff = IE - IE_matlab
IC_diff = IC - IC_matlab

neighbor_diff = neighbor - neighbor_matlab



print(np.sum(IE))
print(np.sum(IC))

print("IE max error:",
      np.max(np.abs(IE_diff)))

print("IC max error:",
      np.max(np.abs(IC_diff)))

print(np.linalg.norm(IC_diff))

# print(sum(sum(t_diff)))
# print(sum(sum(P_diff)))

print(sum(sum(neighbor_diff)))